package org.kente.loans;

public enum Gender {
    M,
    F,
    U
}
